function TLE = getTLE(satellite,varargin)

if strcmpi(satellite,'EV01')||strcmpi(satellite,'EV1')
    NORADID=38709;
elseif strcmpi(satellite,'EV02')||strcmpi(satellite,'EV2')
    NORADID=37387;
elseif strcmpi(satellite,'EV05')||strcmpi(satellite,'EV5')
    NORADID=39416;
elseif strcmpi(satellite,'EV06')||strcmpi(satellite,'EV6')
    NORADID=37793;
elseif strcmpi(satellite,'EV11')
    NORADID=40018;
elseif strcmpi(satellite,'EV12')
    NORADID=39425;
elseif strcmpi(satellite,'EV13')
    NORADID=40019;
elseif strcmpi(satellite,'HPL106')
    NORADID=41919;
elseif strcmpi(satellite,'HPL118')
    NORADID=41923;
elseif strcmpi(satellite,'HPL124')
    NORADID=41926;
elseif strcmpi(satellite,'HPL125')
    NORADID=41925;
elseif strcmpi(satellite,'HPL113')
    NORADID=42812;
elseif isnumeric(satellite)
    NORADID=satellite;
end

tleFolder = 'C:\exactEarth\TLE\';
if nargin == 2
    
    if isnan(satellite)
        currentTLE = false;
        filename = varargin{1};
    else
        
        tleFiles = getFiles(tleFolder);
        if ~isempty(tleFiles)
            tleFiles = tleFiles(~cellfun(@(x) isempty(strfind(x,['_',num2str(NORADID),'.tle'])),tleFiles));
            if ~isempty(tleFiles)
                [~,name,~]=cellfun(@fileparts,tleFiles,'uniformoutput',false);
                fileDates = cellfun(@(x) datenum(x(1:11)),name);
                propDate = varargin{1};
                [dateOffset,ind]=min(abs(fileDates-propDate));
                if abs(floor(now)-propDate)<dateOffset
                    currentTLE = true;
                else
                    currentTLE = false;
                    filename = tleFiles{ind};
                end
            else
                currentTLE = true;
            end
        else
            currentTLE = true;
        end
    end
    
    
    %     currentTLE = false;
    %     filename = varargin{1};
elseif nargin == 1
    currentTLE = true;
else
    error('Invalid number of input arguments');
end



if currentTLE
    url = sprintf('http://celestrak.com/cgi-bin/TLE.pl?CATNR=%d',NORADID);
    
    for i = 1:2
        
        try
            txt = urlread(url);
            break;
        catch
            warn = sprintf('urlread failed - waiting 5 seconds and trying again - attempt %d',i);
            warning(warn)
            pause(5);
            if i==2
                warning('urlread failed 1 times, check network connection, loading EV6 TLE AGM 2018')
%                 error('urlread failed 1 times, check network connection')
                load EV6TLE
            end
        end
    end
    txt = regexprep(txt,'<script.*?/script>','');
    txt = regexprep(txt,'<style.*?/style>','');
    txt = regexprep(txt,'<.*?>','');
    
    str = sprintf('1 %d',NORADID);
    TLE = deblank(txt(strfind(txt,str):end));
    TLE = [TLE(1:69);TLE(71:139)];
    
    year = ['20',TLE(1,19:20)];
    date = datenum(sprintf('January 1, %s',year))+str2num(TLE(1,21:32))-1;
    tleName = sprintf('%s%s_%d.tle',tleFolder,datestr(floor(date),'mmm dd yyyy'),NORADID);
    
    fid = fopen(tleName,'w');
    fprintf(fid,'%s\r\n',TLE(1,:));
    fprintf(fid,'%s\r\n',TLE(2,:));
    fclose(fid);
      
%     save EV6TLE
else
    fid = fopen(filename);
    C = textscan(fid, '%s','delimiter','\n');
    fclose(fid);
    C=C{1,1};
    if isnan(NORADID)
        NORADID = str2num(C{1}(3:7));
    end
    str1 = cell2mat(C(~cellfun(@isempty,strfind(C,['1 ',num2str(NORADID,'%05d')]))));
    str2 = cell2mat(C(~cellfun(@isempty,strfind(C,['2 ',num2str(NORADID,'%05d')]))));
    TLE = [str1;str2];
end
