function pos_gcf = lla_to_gcf(lat_long_alt, R_earth)

% This function calculates the coords in Greenwich current frame from
% lat, long, alt data
%
% Inputs:   lat_long_alt        position in gcf coords
%                               (lat, long, alt), (rad, m)
%           R_earth             earth radius (m)

% Outputs:  pos_gcf             gcf coords
%
% $Revision: 1.1 $
% $Author: coxb $
% $Date: 2007/02/23 18:10:46 $
% $Source: /home/cvsroot/ais_simulator3/simulator/simulator/Generic\040Funtions/lla_to_gcf.m,v $
% Copyright     2006 Analyticon Limited

%**************************************************************************
% calculate position of satellite antennae in earth axes - assume
% co-centred
c_lat = cos(lat_long_alt(:,1));
s_lat = sin(lat_long_alt(:,1));
c_long = cos(lat_long_alt(:,2));
s_long = sin(lat_long_alt(:,2));
radial_dist = R_earth + lat_long_alt(:,3);

pos_gcf =  repmat(radial_dist,1,3).*[...
        c_lat.*c_long,...
        c_lat.*s_long,...
        s_lat];
    
end
