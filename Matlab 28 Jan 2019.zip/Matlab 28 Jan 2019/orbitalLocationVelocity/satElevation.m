function [sat_el,sat_az,pos,range,rangeRate] = satElevation(time,DS,GSLatLon,varargin)

%GSLatLon is [lat,lon]
% GSLatLon = reshape(GSLatLon,[],1);

if size(GSLatLon,2)==2
    GSLatLon = [GSLatLon,zeros(size(GSLatLon,1),1)];
end
rE = 6378.1;
dtr = pi/180;
rtd = 180/pi;
GSLatLon(:,1:2) = GSLatLon(:,1:2)*dtr;

if nargin==4
    pos = varargin{1};
    pos(:,1:2)=pos(:,1:2)*dtr;
elseif nargin==3
    %pos is [lon,lat,alt]
[ pos ] = satPosition( time,DS );
pos(:,1:2)=pos(:,1:2)*dtr;
a=pos(:,1);
pos(:,1)=pos(:,2);
pos(:,2)=a;
else
    error('Invalid Number of Input Arguements')
end

GSPos = lla_to_gcf(GSLatLon, rE);
sat_el=zeros(size(pos,1),1);
sat_az=sat_el;

satgcf = lla_to_gcf((pos), rE);
targetZenithHat = bsxfun (@rdivide, GSPos, sqrt(GSPos(:,1).^2+GSPos(:,2).^2+GSPos(:,3).^2));
target2sat     =  bsxfun (@minus,satgcf, GSPos);
target2SatHat = bsxfun (@rdivide, target2sat, sqrt(target2sat(:,1).^2+target2sat(:,2).^2+target2sat(:,3).^2));
range = sqrt(target2sat(:,1).^2+target2sat(:,2).^2+target2sat(:,3).^2);

% AGM - add some mild Median non-linear filtering to the range data -
% bypass - artifact added at end of record, and some right near the center
% as well
%
if(1==0)
    range      = medfilt1(range,3);
end

rangeRate = diff(range) ./ diff(time).';    % transpose one variable, otherwise square matrix created AGM 11 April 2018

sat_el = zeros(size(target2SatHat,1),1);

for i = 1:size(target2SatHat,1)
    sat_el(i) = real(pi/2-acos(targetZenithHat*target2SatHat(i,:)'))*rtd;
    %el(i)=real(pi/2-acos(targetZenithHat(i,:)*target2SatHat(i,:)'))*rtd;
    sat_az(i)=atan2( target2SatHat(i,2), -target2SatHat(i,1) );
end
% for i=1:size(pos,1)
%     satgcf = lla_to_gcf((pos(i,:))', rE);
%     GSZenithHat = GSPos/norm(GSPos);
%     GS2sat     = satgcf - GSPos;
%     GS2SatHat = GS2sat/norm(GS2sat);
%             
%     sat_el(i) = pi/2 - acos(GSZenithHat'*GS2SatHat);
%     sat_az(i)=atan2( GS2SatHat(2), -GS2SatHat(1) );
% end
sat_el = real(sat_el);
sat_az = mod(real(sat_az*rtd),360);
pos(:,1:2)=pos(:,1:2)*rtd;

