function dn = unixtime_to_datenum( unix_time )
    dn = unix_time/86400 + 719529;         %# == datenum(1970,1,1)
end

% dt = datetime( unix_time, 'ConvertFrom', 'posixtime' );       % newer
% function in Matlab 2015a or newer
% datestr(dt)