function outvec = changefilter2(invec, thresh, quant);
%
% filter to apply threshold and hysteresis to eliminate small dither in
% data sequences
% Arunas Macikunas, Waves in Space Corp., Copyright 2018
% Ver 0.1 3 May 2018
% Ver 0.2 9 May 2018 added quantization to output vector to control
% frequency jitter (noise)
%
invec           = invec.';
lenvec          = length(invec);

% invec           = medfilt1(invec,3);

outvec(1)       = invec(1);
outvec(lenvec)  = invec(lenvec);

% holdlast        = 0;
outvec(1)       = invec(1);

for i = 2:lenvec-1
    x0          = outvec(i-1);
    x1          = invec(i);
    x2          = invec(i+1);
    
    if( abs(x1 - x0) > thresh )        
        outvec(i) = x1;
        holdlast    = 0;
    else       
        outvec(i)   = x0;
        holdlast    = 1;
    end
  
end

% outvec = medfilt1(outvec,3);  % adding a median filter greatly increases
% the error after 1st filter stage

rang            = max(outvec) - min(outvec);
levels          = rang/quant;
skale           = rang / levels;

outvec          = skale * round( outvec/skale );

std(outvec-invec)

% figure(131); plot(invec-outvec,'.');grid; hold on; plot(diff(invec),'r'); plot(diff(outvec),'g'); hold off; xlim([0 140]);

figure(132);  plot(outvec,'.-k'); grid;hold on; plot(10000*(outvec-invec),'.-r'); hold off; xlabel('Sample');ylabel('Frequency (Hz)');title('Output Doppler and 10k X out-in diff');
