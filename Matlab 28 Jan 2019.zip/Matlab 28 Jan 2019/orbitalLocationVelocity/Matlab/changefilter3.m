function outvec = changefilter3(invec, thresh, thresh2);
%
% filter to apply threshold and hysteresis to eliminate small dither in
% data sequences
% Arunas Macikunas, Waves in Space Corp., Copyright 2018
% Ver 0.1 3 May 2018
% Ver 0.2 9 May 2018 added quantization to output vector to control
% Ver 0.3 9 May 2018 added monotonic change detection to prevent 'jitter'
% frequency jitter (noise)
%
invec           = invec.';
lenvec          = length(invec);

% invec           = medfilt1(invec,3);

outvec(1)       = invec(1);
outvec(lenvec)  = invec(lenvec);

% holdlast        = 0;
outvec(1)       = invec(1);

for i = 2:lenvec-1
    x0          = outvec(i-1);
    x1          = invec(i);
    x2          = invec(i+1);
    
    if( (abs(x1 - x0)) > thresh2 )
        outvec(i) = x1;
        holdlast    = 0;
    elseif( (abs(x1 - x0) >= thresh) &&  (abs(x1 - x0) <= thresh2 ) )
        
        if( sign(x2 - x0) ~= sign(x1 - x0) )
            outvec(i)   = x0;
        else
            outvec(i) = x1;
        end
%         outvec(i) = x1;
        holdlast    = 0;
    else
        outvec(i)   = x0;
        holdlast    = 1;
    end
    
end

outvec = medfilt1(outvec,3);  % adding a median filter greatly increases
% the error after 1st filter stage

if(1==0)
    rang            = max(outvec) - min(outvec);
    levels          = rang/quant;
    skale           = rang / levels;
    outvec          = skale * round( outvec/skale );
end

std(outvec-invec)

% figure(131); plot(invec-outvec,'.');grid; hold on; plot(diff(invec),'r'); plot(diff(outvec),'g'); hold off; xlim([0 140]);

figure(132);  plot(outvec,'.-k'); grid;hold on; plot(10000*(outvec-invec),'.-r'); hold off; xlabel('Sample');ylabel('Frequency (Hz)');title('Output Doppler and 10k X out-in diff');
figure(133);  plot(diff(outvec),'.-k'); grid;xlabel('Sample');ylabel('Frequency Diff (Hz)');title('Output Doppler Sample to Sample Diff');
