function [filename]=getFiles( folder,varargin )
%Loop through a folder and process all modem files found
%Input - folder path: folder when the data is being collected from (char)
%      - (Optional)file extension: will only list files of a certain file
%        type (char)
%Output - filename: an cell array of the files that are in the folder with
%         the desired extension (cell m x 1 array)


dir_listing = dir(folder);
filename=cell(0,1);

j=1;

for i =1:length(dir_listing)
    if dir_listing(i).isdir==0
      [path name ext] = fileparts([folder,'\',dir_listing(i).name]);
      if nargin == 2
          if strcmpi(char(varargin(1)),ext(2:length(ext)))==1
             filename{j} = [folder,'\',dir_listing(i).name];
             j=j+1;
          end
      else
          filename{j} = [folder,'\',dir_listing(i).name];
          j=j+1;
      end
      
    end
end
filename = sort(filename);
filename=filename';

