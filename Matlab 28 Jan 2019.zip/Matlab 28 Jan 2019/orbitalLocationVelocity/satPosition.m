function [ pos,posSat,velSat ] = satPosition( t,DS )

%set time to Matlab time
t = datenum(t);
%Julian date offset to Matlab time
JDOffset = 1721058.5;
t = t+JDOffset;
filename=[];

if isnumeric(DS)
    if DS<1500
        switch DS
            case 1
                satellite = 38709;
            case 2
                satellite = 37387;
            case 5
                satellite = 39416;
            case 6
                satellite = 37793;
            case 7
                satellite = 41605;
            case 8
                satellite = 43215;
            case 9
                satellite = 40936;
            case 11
                satellite = 40018;
            case 12
                satellite = 39425;
            case 13
                satellite = 40019;
            case 55
                satellite = 39416;
            case 56
                satellite = 37793;
            case 61
                satellite = 40018;
            case 62
                satellite = 39425;
            case 63
                satellite = 40019;
            case 80
                satellite = 25544;
            case 59
                satellite = 40936;
            case 1106
                satellite = 41919;
            case 1125
                satellite = 41925;
            case 1124
                satellite = 41926;
            case 1118
                satellite = 41923;
            case 1113
                satellite = 42812;
            case 1127
                satellite = 42807;
            case 1131
                satellite = 42804;
            case 1133
                satellite = 42808;
            case 1135
                satellite = 42809;
            case 1123
                satellite = 42806;
            case 1130
                satellite = 42805;
            case 1121
                satellite = 42810;
            case 1126
                satellite = 42811;
            case 1108
                satellite = 42955;
            case 1129
                satellite = 42956;
            case 1140
                satellite = 42957;
            case 1122
                satellite = 42958;
            case 1137
                satellite = 42959;
            case 1136
                satellite = 42961;
            case 1144
                satellite = 42962;
            case 1145
                satellite = 42963;
            case 1134
                satellite = 42964;
             case 1152
                satellite = 43071;
            case 1128
                satellite = 43072;
            case 1142
                satellite = 43073;
            case 1148
                satellite = 43079;
            case 1138
                satellite = 43075;
            case 1132
                satellite = 43070;
            case 1143
                satellite = 43074;
            case 1139
                satellite = 43076;
            case 1169
                satellite = 43078;
            case 1141
                satellite = 43077;
            case 1165
                satellite = 43253;
            case 1147
                satellite = 43258;
            case 1150
                satellite = 43252;
            case 1163
                satellite = 43250;
            case 1176
                satellite = 43256;
            case 1151
                satellite = 43255;
            case 1160
                satellite = 43249;
            case 1167
                satellite = 43254;
            case 1146
                satellite = 43257;
            case 1168
                satellite = 43251;
        end
    else
        satellite=DS;
    end
else
    %exactEarth Satellites are predefined
    switch DS
        case 'DS01'
            satellite = 38709;
        case 'DS02'
            satellite = 37387;
        case 'DS05'
            satellite = 39416;
        case 'DS06'
            satellite = 37793;
        case 'DS07'
            satellite = 41605;
        case 'DS08'
            satellite = 43215;
        case 'DS09'
            satellite = 40936;
        case 'DS11'
            satellite = 40018;
        case 'DS12'
            satellite = 39425;
        case 'DS13'
            satellite = 40019;
        case 'DS55'
            satellite = 39416;
        case 'DS56'
            satellite = 37793;
        case 'DS61'
            satellite = 40018;
        case 'DS62'
            satellite = 39425;
        case 'DS63'
            satellite = 40019;
        case 'DS80'
            satellite = 25544;
        case 'DS59'
            satellite = 40936;
        case 'DS1106'
            satellite = 41919;
        case 'DS1125'
            satellite = 41925;
        case 'DS1124'
            satellite = 41926;
        case 'DS1118'
            satellite = 41923;
        case 'DS1113'
            satellite = 42812;
        case 'DS1127'
            satellite = 42807;
        case 'DS1131'
            satellite = 42804;
        case 'DS1133'
            satellite = 42808;
        case 'DS1135'
            satellite = 42809;
        case 'DS1123'
            satellite = 42806;
        case 'DS1130'
            satellite = 42805;
        case 'DS1121'
            satellite = 42810;
        case 'DS1126'
            satellite = 42811;
        case 'DS1108'
            satellite = 42955;
        case 'DS1129'
            satellite = 42956;
        case 'DS1140'
            satellite = 42957;
        case 'DS1122'
            satellite = 42958;
        case 'DS1137'
            satellite = 42959;
        case 'DS1136'
            satellite = 42961;
        case 'DS1144'
            satellite = 42962;
        case 'DS1145'
            satellite = 42963;
        case 'DS1134'
            satellite = 42964;
        case 'DS1152'
            satellite = 43071;
        case 'DS1128'
            satellite = 43072;
        case 'DS1142'
            satellite = 43073;
        case 'DS1148'
            satellite = 43079;
        case 'DS1138'
            satellite = 43075;
        case 'DS1132'
            satellite = 43070;
        case 'DS1143'
            satellite = 43074;
        case 'DS1139'
            satellite = 43076;
        case 'DS1169'
            satellite = 43078;
        case 'DS1141'
            satellite = 43077;
        case 'DS1165'
            satellite = 43253;
        case 'DS1147'
            satellite = 43258;
        case 'DS1150'
            satellite = 43252;
        case 'DS1163'
            satellite = 43250;
        case 'DS1176'
            satellite = 43256;
        case 'DS1151'
            satellite = 43255;
        case 'DS1160'
            satellite = 43249;
        case 'DS1167'
            satellite = 43254;
        case 'DS1146'
            satellite = 43257;
        case 'DS1168'
            satellite = 43251;
        otherwise
            %TLE file
            if ~isempty(strfind(DS,'.txt'))||~isempty(strfind(DS,'.tle'))
                filename = DS;
                satellite=nan;
            else
                error('Unknown Data Source')
            end
    end
end

%if a file is not selected, the most recent TLE from Celestrak is collected
if isempty(filename)
%     TLE = getTLE(satellite(1),floor(t(1)-JDOffset));
    TLE = getTLE(satellite(1),(t(1)-JDOffset));

    % good location to print out or confirm TLE was obtained
else
    TLE = getTLE(satellite,filename);
end
% TLE(2,:) = TLE(2,2:end);

%Parse TLE and find offset from TLE epoch
satrec = parseTwoLine(84,TLE(1,:),strtrim(TLE(2,:)));
dt = (t-satrec.jdsatepoch)*1440;

%pre-allocate space for satellite position
posSat = zeros(length(dt),3);
velSat = zeros(length(dt),3);

%loop through each time in dt
for i = 1:length(dt)
    %use SGP4 propagator to find satellite position in ECI reference frame
    [~, posSat(i,:), velSat(i,:)] = sgp4(satrec,dt(i));
    %find offset between ECI and ECEF reference frames (z-axis in both
    %frames are the same and therefore unaffected)
    GMST = JD2GMST(t(i));
    
    %rotate position to ECEF reference frame
    tempPos1=[cosd(-GMST),-sind(-GMST);sind(-GMST),cosd(-GMST)]*posSat(i,1:2)';
    posSat(i,1:2)=tempPos1;
end

%find lat/lon/alt
lon = atan2(posSat(:,2),posSat(:,1))*180/pi;
lat = atan2(posSat(:,3),sqrt(posSat(:,1).^2+posSat(:,2).^2))*180/pi;
alt = sqrt(posSat(:,1).^2+posSat(:,2).^2+posSat(:,3).^2)-6378.1;

pos = [lon,lat,alt];
end

